-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 30-Jun-2022 às 04:00
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `minhaempresa_bd`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE `produtos` (
  `id_produto` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `valor` float(10,0) NOT NULL,
  `imagem` varchar(255) NOT NULL,
  `categoria` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`id_produto`, `nome`, `valor`, `imagem`, `categoria`) VALUES
(6, 'Moletom Nike Preto', 160, '2022.06.30-03.53.29jpeg', 'Casaco de moletom'),
(7, 'Moletom Nike Cinza', 160, '2022.06.30-03.53.47jpeg', 'Casaco de moletom'),
(8, 'Moletom Tommy Vermelho', 160, '2022.06.30-03.54.01jpeg', 'Casaco de moletom'),
(9, 'Calça de moletom Adidas Preta', 85, '2022.06.30-03.54.24jpeg', 'Calça de moletom'),
(10, 'Sueter Tommy Branco', 165, '2022.06.30-03.55.27jpeg', 'Sueter'),
(11, 'Sueter Tommy Preto', 165, '2022.06.30-03.57.51jpeg', 'Sueter'),
(12, 'Sueter Lacoste Preto', 165, '2022.06.30-03.55.38jpeg', 'Sueter'),
(14, 'Moletom Tommy Preto', 160, '2022.06.30-03.55.52jpeg', 'Casaco de moletom'),
(15, 'Calça de moletom Lascoste Cinza', 85, '2022.06.30-03.56.18jpeg', 'Calça de moletom'),
(16, 'Calça de moletom Lascoste Preta', 85, '2022.06.30-03.56.30jpeg', 'Calça de moletom'),
(18, 'Sueter Lacoste Azul', 165, '2022.06.30-03.56.41jpeg', 'Sueter'),
(19, 'Corta Vento Nike Preta', 100, '2022.06.30-03.56.52jpeg', 'Corta Vento'),
(20, 'Corta Vento Nike Vermelha', 100, '2022.06.30-03.57.05jpeg', 'Corta Vento'),
(21, 'Corta Vento Nike Branca', 100, '2022.06.30-03.57.16jpeg', 'Corta Vento'),
(22, 'Corta Vento Nike Azul', 100, '2022.06.30-03.57.25jpeg', 'Corta Vento');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nome`, `email`, `senha`) VALUES
(1, 'bruno', 'admin@admin', 'admin');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id_produto`);

--
-- Índices para tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id_produto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
