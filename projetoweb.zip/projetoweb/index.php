<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Site de Vendas responsivo</title>

    <!-- owl carousel css file cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="style.css">

</head>
<body>

<!-- header section starts  -->

<header>

<div class="header-1">

    <a href="#" class="logo"> <i class="fas fa-shopping-bag"></i>  Minha Loja </a>

    <div class="form-container">
        <form action="">
            <input type="search" placeholder="pesquisar..." id="search" /> 
            <label for="search" class="fas fa-search"></label>
        </form>
    </div>

</div>

<div class="header-2">

    <div id="menu" class="fas fa-bars"></div>

    <nav class="navbar">
        <ul>
            <li><a class="active" href="#home">início</a></li>
            <li><a href="#arrival">produtos</a></li>
            <li><a href="#featured">destaques</a></li>
            <li><a href="#gallery">loja</a></li>
            <li><a href="#deal">promoções</a></li>
        </ul>
    </nav>

    <div class="icons">
        <a href="#" class="fas fa-heart"></a>
        <a href="#" class="fas fa-shopping-cart"></a>
        <a href="#" class="fas fa-user"></a>
    </div>

</div>

</header>

<!-- header section ends -->

<!-- home section starts  -->

<section class="home" id="home">

<div class="home-slider owl-carousel">

    <div class="item">
        <img src="images/ola.png" alt="">
        <div class="content">
         <!--   <h3>Melhores descontos</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed, neque.</p>
            <a href="#"><button class="btn">Ver mais</button></a>-->
        </div>
    </div>

    <div class="item">
        <img src="images/oi.png" alt="">
      <!--   <div class="content">
            <h3>Mais recentes</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed, neque.</p>
            <a href="#"><button class="btn">Ver mais</button></a>
        </div>-->
    </div>

    </div>

</div>

</section>

<!-- home section ends -->

<!-- arrival section starts  -->

<section class="arrival" id="arrival">

<h1 class="heading"> <span>novos produtos</span> </h1>


<div class="produtos">
    <?php
    include("admin/config/conexao.php");
    $res = mysqli_query($link,"SELECT *FROM produtos order by rand() limit 6");
    while($show=mysqli_fetch_assoc($res)){
      $nome = $show['nome'];
      $valor = $show['valor'];
      $imagem = $show['imagem'];     
  ?>
        <div class="card">
        <div class="col-lg-4">
        <img src="admin/images/<?php echo $imagem ?>" class="rounded mx-auto d-block" width="250"/>
        <h2 class="fw-normal"><?php echo $nome ?></h2>
        <p><?php echo $valor ?></p>
        <p><a class="btn btn-secondary" href="#">Comprar</a></p>
        </div>
        </div><!-- /.col-lg-4 -->
        <?php } ?>  

    </div> 



</section>

<!-- arrival section ends -->

<!-- featured section starts  -->

<section class="feature" id="featured">

<h1 class="heading"> <span> produtos em destaque </span> </h1>

<div class="row">

    <div class="image-container">

        <div class="big-image">
        <?php
    include("admin/config/conexao.php");
    $res = mysqli_query($link,"SELECT *FROM produtos order by rand() limit 1");
    while($show=mysqli_fetch_assoc($res)){
      $nome = $show['nome'];
      $valor = $show['valor'];
      $imagem = $show['imagem'];     
  ?>
        <div class="card">
        <div class="col-lg-4">
        <img src="admin/images/<?php echo $imagem ?>" class="rounded mx-auto d-block" width="250"/>
        
        </div>
        </div>
        <?php } ?>  
        </div>

  

    </div>

    <div class="content">

        <h3><h2 class="fw-normal"><?php echo $nome ?></h2></h3>
        <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <span>(500+) avaliações</span>
        </div>
        <p>Promoção imperdivel corre adquirir o seu</p>
        <strong class="price"><?php echo $valor ?></strong>
        <a href="#"><button class="btn">comprar</button></a>

    </div>

</div>

</section>

<!-- featured section ends -->

<!-- gallery section starts  -->

<section class="gallery" id="gallery">

<h1 class="heading"> <span> loja </span> </h1>

<ul class="controls">
    <li class="btn button-active" data-filter="all">Tudo</li>
    <li class="btn" data-filter="Moletom">Moletom</li>
    <li class="btn" data-filter="Sueter">Sueter</li>
    <li class="btn" data-filter="Corta">Corta Vento</li>
    <li class="btn" data-filter="Calça">Calça</li>
</ul>

<div class="image-container">
<?php
    include("admin/config/conexao.php");
    $res = mysqli_query($link,"SELECT nome,imagem,valor from produtos where categoria = 'Casaco de Moletom' ");
    while($show=mysqli_fetch_assoc($res)){
      $nome = $show['nome'];
      $valor = $show['valor'];
      $imagem = $show['imagem'];     
  ?>
    <div class="box Moletom">
        <div class="image">
        <img src="admin/images/<?php echo $imagem ?>" class="rounded mx-auto d-block" width="250"/>
        </div>
        <div class="info">
            <h3><?php echo $nome ?></h3>
            <div class="subInfo">
                <strong class="price"><?php echo $valor ?></strong>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half"></i>
                </div>
            </div>
        </div>
    </div> <?php } ?>  

    <?php
    include("admin/config/conexao.php");
    $res = mysqli_query($link,"SELECT nome,imagem,valor from produtos where categoria = 'Sueter' ");
    while($show=mysqli_fetch_assoc($res)){
      $nome = $show['nome'];
      $valor = $show['valor'];
      $imagem = $show['imagem'];     
  ?>
    <div class="box Sueter">
    <div class="image">
        <img src="admin/images/<?php echo $imagem ?>" class="rounded mx-auto d-block" width="250"/>
        </div>
        <div class="info">
            <h3><?php echo $nome ?></h3>
            <div class="subInfo">
                <strong class="price"><?php echo $valor ?></strong>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half"></i>
                </div>
            </div>
        </div>
    </div> <?php } ?>  

    <?php
    include("admin/config/conexao.php");
    $res = mysqli_query($link,"SELECT nome,imagem,valor from produtos where categoria = 'Corta Vento' ");
    while($show=mysqli_fetch_assoc($res)){
      $nome = $show['nome'];
      $valor = $show['valor'];
      $imagem = $show['imagem'];     
  ?>
    <div class="box Corta">
    <div class="image">
        <img src="admin/images/<?php echo $imagem ?>" class="rounded mx-auto d-block" width="250"/>
        </div>
        <div class="info">
            <h3><?php echo $nome ?></h3>
            <div class="subInfo">
                <strong class="price"><?php echo $valor ?></strong>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half"></i>
                </div>
            </div>
        </div>
    </div> <?php } ?>  


    <?php
    include("admin/config/conexao.php");
    $res = mysqli_query($link,"SELECT nome,imagem,valor from produtos where categoria = 'Calça de moletom' ");
    while($show=mysqli_fetch_assoc($res)){
      $nome = $show['nome'];
      $valor = $show['valor'];
      $imagem = $show['imagem'];
      ?> 
    <div class="box Calça">
    <div class="image">
        <img src="admin/images/<?php echo $imagem ?>" class="rounded mx-auto d-block" width="250"/>
        </div>
        <div class="info">
            <h3><?php echo $nome ?></h3>
            <div class="subInfo">
                <strong class="price"><?php echo $valor ?></strong>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half"></i>
                </div>
            </div>
        </div>
    </div> <?php } ?>  

   
</section>

<!-- gallery section ends -->

<!-- deal section starts  -->

<section class="deal" id="deal">

<h1 class="heading"> <span> melhores promoções </span> </h1>

<div class="box-container">

    <div class="box">
        <img src="images/deal12.jpg" alt="">
        <div class="content">
            <h3>Moletom</h3>
            <p>25% off na primeira compra</p>
            <a href="#"><button class="btn">explorar</button></a>
        </div>
    </div>

    <div class="box">
        <img src="images/deal123.jpg" alt="">
        <div class="content">
            <h3>Sueter</h3>
            <p>25% off na primeira compra</p>
            <a href="#"><button class="btn">explorar</button></a>
        </div>
    </div>

</div>

<div class="icons-container">

    <div class="icons">
        <i class="fas fa-shipping-fast"></i>
        <h3>Entrega rápida</h3>
        <p>Entregas via</p>
    </div>

    <div class="icons">
        <i class="fas fa-user-clock"></i>
        <h3>suporte</h3>
        <p>Só chamar no whatswapp</p>
    </div>

    <div class="icons">
        <i class="fas fa-money-check-alt"></i>
        <h3>Formas de pagamento</h3>
        <p>Pix e Cartao de credito</p>
    </div>

    <div class="icons">
        <i class="fas fa-box"></i>
        <h3>10 dias de troca</h3>
        <p>Lembrando que precisa estar com a etiqueta no produtos</p>
    </div>

</div>

</section>

<!-- deal section ends -->

<!-- newsletter section starts  -->

<section class="newsletter">

    <h1>Noticias</h1>
    <p>Clique aqui para ver últimos descontos e atualizações</p>
    <form action="">
        <input type="email" placeholder="insira seu email">
        <input type="submit" class="btn" value="Enviar">
    </form>

</section>

<!-- newsletter section ends -->

<!-- footer section starts  -->

<section class="footer">

    <div class="box-container">

        <div class="box">
            <a href="#" class="logo"> <i class="fas fa-shopping-bag"></i>  minha loja </a>
            <p>Loja online, vendemos roupas masculinas e femininas.</p>
        </div>

        <div class="box">
            <h3>links</h3>
            <a href="#">inicio</a>
            <a href="#">produtos</a>
            <a href="#">destaques</a>
            <a href="#">loja</a>
            <a href="#">promoções</a>
        </div>

        <div class="box">
            <h3>Contatos</h3>
            <p> <i class="fas fa-home"></i>
                Chapecó, Santa Caterina, 
                Brasil 
            </p>
            <p> <i class="fas fa-phone"></i>
                +5549999722838
            </p>
            <p> <i class="fas fa-globe"></i>
            eduardo.santos8@alunos.sc.senac.br

            </p>
        </div>

    </div>

<h1 class="credit"> Criado por <span>Eduardo</span> | inspirado em Raniely </h1>

</section>

<!-- footer section ends -->











<!-- jquery cdn link  -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- owl carousel js file cdn link  -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>

<!-- custom js file link  -->
<script src="script.js"></script>
    
</body>
</html>