# Site de vendas

Nesse repositório você encontra um projeto de um site responsivo para uma empresa fictícia construído com HTML/CSS, com intuito de treinar Flexbox e responsividade. 

## Projeto finalizado:

![Output sample](https://github.com/RanielyFreitas/Site-de-vendas-responsivo/blob/maIN/images/site.gif)
